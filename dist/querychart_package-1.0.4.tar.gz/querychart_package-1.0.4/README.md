# querychart
sql graphs based on matplotlib

## install matplotlib
```
pip install matplotlib
```





### marker ref 
https://www.w3schools.com/python/matplotlib_markers.asp
